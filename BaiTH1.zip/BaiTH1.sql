-- ============================================================
-- BAI THUC HANH 1 - SQL Server Version
-- Mon: Co So Du Lieu
-- ============================================================

-- ============================================================
-- BUOC 1: Tao CSDL BaiTH1
-- ============================================================
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'BaiTH1')
BEGIN
    CREATE DATABASE BaiTH1;
END
GO

USE BaiTH1;
GO

-- ============================================================
-- BUOC 2: Tao bang SinhVien (cau 6)
-- Tuong duong tao table trong Access
-- ============================================================
IF OBJECT_ID('dbo.SinhVien', 'U') IS NOT NULL
    DROP TABLE dbo.SinhVien;
GO

CREATE TABLE dbo.SinhVien (
    MaSV       NVARCHAR(10)    NOT NULL,   -- ShortText, 10, khoa chinh
    HoSV       NVARCHAR(50)    NULL,        -- ShortText, 50
    TenSV      NVARCHAR(20)    NULL,        -- ShortText, 20
    NgaySinh   DATE            NULL,        -- Date/Time, ShortDate
    DiaChi     NVARCHAR(100)   NULL,        -- ShortText, 100
    GioiTinh   NVARCHAR(20)    NULL,        -- ShortText, 20
    MaLop      NVARCHAR(8)     NULL,        -- ShortText, 8
    QueQuan    NVARCHAR(50)    NULL,        -- ShortText, 50
    GhiChu     NVARCHAR(MAX)   NULL,        -- LongText

    CONSTRAINT PK_SinhVien PRIMARY KEY (MaSV)
);
GO

-- ============================================================
-- BUOC 3: Nhap lieu >= 5 hang (cau 7)
-- ============================================================
INSERT INTO dbo.SinhVien (MaSV, HoSV, TenSV, NgaySinh, DiaChi, GioiTinh, MaLop, QueQuan, GhiChu)
VALUES
    ('SV001', N'Nguyen Van', N'An',     '2003-05-15', N'123 Ly Thuong Kiet, Q1, TP.HCM', N'Nam',  'CNTT01', N'Tien Giang',   N'Hoc luc kha'),
    ('SV002', N'Tran Thi',  N'Binh',   '2002-11-20', N'45 Nguyen Hue, Q1, TP.HCM',      N'Nu',   'CNTT01', N'Tay Ninh',    N'Hoc luc gioi'),
    ('SV003', N'Le Hoang',  N'Cuong',  '2003-08-30', N'78 CMT8, Q3, TP.HCM',            N'Nam',  'CNTT02', N'Binh Duong',  NULL),
    ('SV004', N'Pham Ngoc', N'Dung',   '2001-03-12', N'99 Vo Van Tan, Q3, TP.HCM',      N'Nu',   'CNTT02', N'Thua Thien Hue', N'Sinh vien ngoai tinh'),
    ('SV005', N'Hoang Minh',N'Em',     '2004-07-01', N'12 Tran Hung Dao, Q5, TP.HCM',   N'Nam',  'CNTT03', N'Thanh Hoa',   NULL),
    ('SV006', N'Vo Thi',    N'Phuong', '2003-01-25', N'56 Dien Bien Phu, Q3, TP.HCM',   N'Nu',   'CNTT01', N'Thai Binh',   N'Can bo lop'),
    ('SV007', N'Bui Thanh', N'Tung',   '2002-09-18', N'34 Hai Ba Trung, Q1, TP.HCM',    N'Nam',  'CNTT03', N'Tuyen Quang', NULL);
GO

-- ============================================================
-- CAU 8: Tao view giong bang SinhVien (day du cac field)
-- ============================================================
IF OBJECT_ID('dbo.vw_SinhVien_All', 'V') IS NOT NULL
    DROP VIEW dbo.vw_SinhVien_All;
GO

CREATE VIEW dbo.vw_SinhVien_All AS
    SELECT
        MaSV,
        HoSV,
        TenSV,
        NgaySinh,
        DiaChi,
        GioiTinh,
        MaLop,
        QueQuan,
        GhiChu
    FROM dbo.SinhVien;
GO

-- Kiem tra
SELECT * FROM dbo.vw_SinhVien_All;
GO

-- ============================================================
-- CAU 9: Query hien 3 field: MaSV, HoSV, TenSV
-- ============================================================
SELECT
    MaSV,
    HoSV,
    TenSV
FROM dbo.SinhVien;
GO

-- ============================================================
-- CAU 10: Query hien 3 field: MaSV, HoTenSV, QueQuan
--          (Ho va ten gop chung 1 field)
-- ============================================================
SELECT
    MaSV,
    (HoSV + N' ' + TenSV) AS HoTenSV,
    QueQuan
FROM dbo.SinhVien;
GO

-- ============================================================
-- CAU 11: Query hien MaSV, HoTenSV, QueQuan
--          Sap xep ten SV tu A->Z (theo TenSV)
-- ============================================================
SELECT
    MaSV,
    (HoSV + N' ' + TenSV) AS HoTenSV,
    QueQuan
FROM dbo.SinhVien
ORDER BY TenSV ASC;
GO

-- ============================================================
-- CAU 12: Query hien MaSV, HoTenSV, QueQuan
--          Chi lay SV co que quan bat dau bang chu 'T'
-- ============================================================
SELECT
    MaSV,
    (HoSV + N' ' + TenSV) AS HoTenSV,
    QueQuan
FROM dbo.SinhVien
WHERE QueQuan LIKE N'T%';
GO

-- ============================================================
-- CAU 13: Query hien MaSV, HoTenSV, QueQuan
--          Chi lay SV lon hon 20 tuoi (tinh tu nam hien tai)
-- ============================================================
SELECT
    MaSV,
    (HoSV + N' ' + TenSV)                          AS HoTenSV,
    QueQuan,
    DATEDIFF(YEAR, NgaySinh, GETDATE())             AS Tuoi
FROM dbo.SinhVien
WHERE DATEDIFF(YEAR, NgaySinh, GETDATE()) > 20;
GO

-- ============================================================
-- END OF SCRIPT
-- ============================================================
