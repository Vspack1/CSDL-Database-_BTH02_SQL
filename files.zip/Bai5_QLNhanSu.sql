-- =============================================
-- BAI 5: QUAN LY NHAN SU DU AN (Powersoft)
-- File: Bai5_QLNhanSu.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLNhanSu')
    DROP DATABASE QLNhanSu;
GO

CREATE DATABASE QLNhanSu;
GO

USE QLNhanSu;
GO

-- =============================================
-- BANG NHAN VIEN
-- =============================================
CREATE TABLE NHAN_VIEN (
    MaNhanVien   NVARCHAR(10)  NOT NULL,
    TenNhanVien  NVARCHAR(50)  NOT NULL,
    BangCap      NVARCHAR(50)  NULL,
    NamSinh      INT           NULL,
    DiaChi       NVARCHAR(100) NULL,
    ChucVu       NVARCHAR(50)  NULL,
    CONSTRAINT PK_NHAN_VIEN PRIMARY KEY (MaNhanVien)
);
GO

-- =============================================
-- BANG DU AN
-- =============================================
CREATE TABLE DU_AN (
    MaDuAn              NVARCHAR(10)  NOT NULL,
    TenDuAn             NVARCHAR(100) NOT NULL,
    NgayDuKienBatDau    DATE          NULL,
    NgayBatDau          DATE          NULL,
    NgayDuKienKetThuc   DATE          NULL,
    NgayKetThuc         DATE          NULL,
    GhiChu              NVARCHAR(MAX) NULL,
    CONSTRAINT PK_DU_AN PRIMARY KEY (MaDuAn)
);
GO

-- =============================================
-- BANG THAM GIA DU AN (quan he n-n)
-- Mot NV co the tham gia mot DA nhieu lan
-- => khoa chinh: MaNhanVien + MaDuAn + NgayBatDauThamGia
-- =============================================
CREATE TABLE THAM_GIA (
    MaNhanVien       NVARCHAR(10)  NOT NULL,
    MaDuAn           NVARCHAR(10)  NOT NULL,
    NgayBatDauThamGia DATE         NOT NULL,
    NgayKetThucThamGia DATE        NULL,
    NhiemVu          NVARCHAR(100) NULL,
    DanhGiaKetQua    NVARCHAR(100) NULL,
    CONSTRAINT PK_THAM_GIA PRIMARY KEY (MaNhanVien, MaDuAn, NgayBatDauThamGia),
    CONSTRAINT FK_THAMGIA_NHANVIEN FOREIGN KEY (MaNhanVien)
        REFERENCES NHAN_VIEN(MaNhanVien)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_THAMGIA_DUAN FOREIGN KEY (MaDuAn)
        REFERENCES DU_AN(MaDuAn)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO NHAN_VIEN VALUES
    ('NV001', N'Nguyễn Văn An', N'Thạc sĩ CNTT', 1990, N'45 Lạc Long Quân, Q11', N'Lập trình viên Senior'),
    ('NV002', N'Trần Thị Bích', N'Kỹ sư CNTT', 1993, N'67 Âu Cơ, Q11', N'Lập trình viên'),
    ('NV003', N'Lê Minh Chiến', N'Cử nhân CNTT', 1995, N'89 Lý Thái Tổ, Q10', N'Kiểm thử phần mềm');

INSERT INTO DU_AN VALUES
    ('DA001', N'Hệ thống quản lý bán hàng', '2024-01-01', '2024-01-10', '2024-06-30', NULL, N'Dự án trọng điểm Q1'),
    ('DA002', N'App mobile giao đồ ăn', '2024-02-01', '2024-02-15', '2024-08-31', NULL, NULL),
    ('DA003', N'Website thương mại điện tử', '2024-03-01', '2024-03-05', '2024-09-30', NULL, N'Hợp đồng với khách hàng Hàn Quốc');

INSERT INTO THAM_GIA VALUES
    ('NV001', 'DA001', '2024-01-10', '2024-03-31', N'Thiết kế kiến trúc hệ thống', N'Xuất sắc'),
    ('NV001', 'DA001', '2024-05-01', NULL, N'Hỗ trợ triển khai', NULL),
    ('NV002', 'DA002', '2024-02-15', NULL, N'Lập trình backend', N'Tốt'),
    ('NV003', 'DA001', '2024-01-10', NULL, N'Kiểm thử', NULL),
    ('NV003', 'DA003', '2024-03-05', NULL, N'Kiểm thử tích hợp', NULL);
GO

PRINT N'Bai 5 - QLNhanSu da tao thanh cong!';
GO
