-- =============================================
-- BAI 8: QUAN LY CHUYEN BAY
-- File: Bai8_QLChuyenBay.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLChuyenBay')
    DROP DATABASE QLChuyenBay;
GO

CREATE DATABASE QLChuyenBay;
GO

USE QLChuyenBay;
GO

-- =============================================
-- BANG MAY BAY
-- =============================================
CREATE TABLE MAY_BAY (
    MaMayBay      NVARCHAR(10)  NOT NULL,
    HangSanXuat   NVARCHAR(50)  NULL,
    NamSanXuat    INT           NULL,
    SoHieuModel   NVARCHAR(20)  NULL,
    SoChoNgoi     INT           NULL,
    TrongTai      DECIMAL(10,2) NULL, -- don vi: tan
    CONSTRAINT PK_MAY_BAY PRIMARY KEY (MaMayBay)
);
GO

-- =============================================
-- BANG TUYEN BAY
-- =============================================
CREATE TABLE TUYEN_BAY (
    MaTuyenBay   NVARCHAR(10)  NOT NULL,
    DiemDi       NVARCHAR(50)  NOT NULL,
    DiemDen      NVARCHAR(50)  NOT NULL,
    KhoangCach   INT           NULL, -- don vi: km
    CONSTRAINT PK_TUYEN_BAY PRIMARY KEY (MaTuyenBay)
);
GO

-- =============================================
-- BANG NHAN SU (dung chung cho phi cong, tiep vien)
-- =============================================
CREATE TABLE NHAN_SU (
    MaNhanSu    NVARCHAR(10)  NOT NULL,
    HoTen       NVARCHAR(50)  NOT NULL,
    NgaySinh    DATE          NULL,
    SoDienThoai NVARCHAR(15)  NULL,
    VaiTro      NVARCHAR(20)  NOT NULL, -- 'Phi cong' hoac 'Tiep vien'
    CONSTRAINT PK_NHAN_SU PRIMARY KEY (MaNhanSu),
    CONSTRAINT CK_NHANSU_VAITRO CHECK (VaiTro IN (N'Phi công', N'Tiếp viên'))
);
GO

-- =============================================
-- BANG HANH KHACH
-- =============================================
CREATE TABLE HANH_KHACH (
    MaHanhKhach NVARCHAR(10)  NOT NULL,
    HoTen       NVARCHAR(50)  NOT NULL,
    NgaySinh    DATE          NULL,
    SoDienThoai NVARCHAR(15)  NULL,
    CCCD        NVARCHAR(20)  NULL,
    CONSTRAINT PK_HANH_KHACH PRIMARY KEY (MaHanhKhach)
);
GO

-- =============================================
-- BANG CHUYEN BAY
-- =============================================
CREATE TABLE CHUYEN_BAY (
    MaChuyenBay     NVARCHAR(10)  NOT NULL,
    MaMayBay        NVARCHAR(10)  NOT NULL,
    MaTuyenBay      NVARCHAR(10)  NOT NULL,
    NgayGioCatCanh  DATETIME      NOT NULL,
    NgayGioHaCanh   DATETIME      NULL,
    MaPhiCongChinh  NVARCHAR(10)  NOT NULL,
    CONSTRAINT PK_CHUYEN_BAY PRIMARY KEY (MaChuyenBay),
    CONSTRAINT FK_CB_MAYBAY FOREIGN KEY (MaMayBay)
        REFERENCES MAY_BAY(MaMayBay),
    CONSTRAINT FK_CB_TUYENBAY FOREIGN KEY (MaTuyenBay)
        REFERENCES TUYEN_BAY(MaTuyenBay),
    CONSTRAINT FK_CB_PHICONGHCHINH FOREIGN KEY (MaPhiCongChinh)
        REFERENCES NHAN_SU(MaNhanSu)
);
GO

-- =============================================
-- BANG PHI CONG PHU CHUYEN BAY (1 chuyen co 2 phi cong phu)
-- =============================================
CREATE TABLE PHI_CONG_PHU (
    MaChuyenBay NVARCHAR(10) NOT NULL,
    MaNhanSu    NVARCHAR(10) NOT NULL,
    CONSTRAINT PK_PHI_CONG_PHU PRIMARY KEY (MaChuyenBay, MaNhanSu),
    CONSTRAINT FK_PCP_CHUYEN FOREIGN KEY (MaChuyenBay)
        REFERENCES CHUYEN_BAY(MaChuyenBay)
        ON DELETE CASCADE,
    CONSTRAINT FK_PCP_NHANSU FOREIGN KEY (MaNhanSu)
        REFERENCES NHAN_SU(MaNhanSu)
);
GO

-- =============================================
-- BANG TIEP VIEN CHUYEN BAY
-- =============================================
CREATE TABLE TIEP_VIEN_CHUYEN_BAY (
    MaChuyenBay NVARCHAR(10) NOT NULL,
    MaNhanSu    NVARCHAR(10) NOT NULL,
    CONSTRAINT PK_TIEP_VIEN_CB PRIMARY KEY (MaChuyenBay, MaNhanSu),
    CONSTRAINT FK_TVCB_CHUYEN FOREIGN KEY (MaChuyenBay)
        REFERENCES CHUYEN_BAY(MaChuyenBay)
        ON DELETE CASCADE,
    CONSTRAINT FK_TVCB_NHANSU FOREIGN KEY (MaNhanSu)
        REFERENCES NHAN_SU(MaNhanSu)
);
GO

-- =============================================
-- BANG HANH KHACH CHUYEN BAY
-- =============================================
CREATE TABLE HANH_KHACH_CHUYEN_BAY (
    MaChuyenBay NVARCHAR(10) NOT NULL,
    MaHanhKhach NVARCHAR(10) NOT NULL,
    SoGhe       NVARCHAR(5)  NULL,
    CONSTRAINT PK_HKCB PRIMARY KEY (MaChuyenBay, MaHanhKhach),
    CONSTRAINT FK_HKCB_CHUYEN FOREIGN KEY (MaChuyenBay)
        REFERENCES CHUYEN_BAY(MaChuyenBay)
        ON DELETE CASCADE,
    CONSTRAINT FK_HKCB_HANHKHACH FOREIGN KEY (MaHanhKhach)
        REFERENCES HANH_KHACH(MaHanhKhach)
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO MAY_BAY VALUES
    ('MB001', N'Boeing', 2015, 'B787-9', 296, 228.00),
    ('MB002', N'Airbus', 2018, 'A321neo', 194, 97.00),
    ('MB003', N'Boeing', 2019, 'B737-800', 162, 79.00);

INSERT INTO TUYEN_BAY VALUES
    ('TB001', N'Hà Nội', N'TP. Hồ Chí Minh', 1150),
    ('TB002', N'TP. Hồ Chí Minh', N'Hà Nội', 1150),
    ('TB003', N'Hà Nội', N'Đà Nẵng', 760);

INSERT INTO NHAN_SU VALUES
    ('NS001', N'Nguyễn Trọng An', '1980-04-10', '0901000001', N'Phi công'),
    ('NS002', N'Trần Minh Bảo', '1982-09-15', '0901000002', N'Phi công'),
    ('NS003', N'Lê Thanh Cường', '1985-12-20', '0901000003', N'Phi công'),
    ('NS004', N'Phạm Thị Duyên', '1995-06-05', '0901000004', N'Tiếp viên'),
    ('NS005', N'Hoàng Thị Em', '1997-03-22', '0901000005', N'Tiếp viên');

INSERT INTO HANH_KHACH VALUES
    ('HK001', N'Đinh Văn Phát', '1990-01-01', '0911000001', '001234567890'),
    ('HK002', N'Vũ Thị Quỳnh', '1993-07-14', '0911000002', '001234567891'),
    ('HK003', N'Bùi Xuân Rạng', '1988-11-30', '0911000003', '001234567892');

INSERT INTO CHUYEN_BAY VALUES
    ('CB001', 'MB001', 'TB001', '2024-05-01 06:00:00', '2024-05-01 08:10:00', 'NS001'),
    ('CB002', 'MB002', 'TB002', '2024-05-01 09:00:00', '2024-05-01 11:05:00', 'NS002'),
    ('CB003', 'MB003', 'TB003', '2024-05-02 07:30:00', '2024-05-02 08:45:00', 'NS003');

INSERT INTO PHI_CONG_PHU VALUES
    ('CB001', 'NS002'),
    ('CB001', 'NS003'),
    ('CB002', 'NS001'),
    ('CB002', 'NS003'),
    ('CB003', 'NS001'),
    ('CB003', 'NS002');

INSERT INTO TIEP_VIEN_CHUYEN_BAY VALUES
    ('CB001', 'NS004'),
    ('CB001', 'NS005'),
    ('CB002', 'NS004'),
    ('CB003', 'NS005');

INSERT INTO HANH_KHACH_CHUYEN_BAY VALUES
    ('CB001', 'HK001', '12A'),
    ('CB001', 'HK002', '12B'),
    ('CB002', 'HK003', '5C'),
    ('CB003', 'HK001', '8D');
GO

PRINT N'Bai 8 - QLChuyenBay da tao thanh cong!';
GO
