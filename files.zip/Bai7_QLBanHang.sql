-- =============================================
-- BAI 7: QUAN LY BAN HANG
-- File: Bai7_QLBanHang.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLBanHang')
    DROP DATABASE QLBanHang;
GO

CREATE DATABASE QLBanHang;
GO

USE QLBanHang;
GO

-- =============================================
-- BANG KHACH HANG
-- =============================================
CREATE TABLE KHACH_HANG (
    MaKhachHang  NVARCHAR(10)  NOT NULL,
    Ho           NVARCHAR(50)  NULL,
    Ten          NVARCHAR(20)  NOT NULL,
    NgaySinh     DATE          NULL,
    GioiTinh     NVARCHAR(10)  NULL,
    DiaChi       NVARCHAR(100) NULL,
    SoDienThoai  NVARCHAR(15)  NULL,
    CONSTRAINT PK_KHACH_HANG PRIMARY KEY (MaKhachHang)
);
GO

-- =============================================
-- BANG NHAN VIEN
-- =============================================
CREATE TABLE NHAN_VIEN (
    MaNhanVien  NVARCHAR(10)  NOT NULL,
    Ho          NVARCHAR(50)  NULL,
    Ten         NVARCHAR(20)  NOT NULL,
    NgaySinh    DATE          NULL,
    GioiTinh    NVARCHAR(10)  NULL,
    DiaChi      NVARCHAR(100) NULL,
    SoDienThoai NVARCHAR(15)  NULL,
    CONSTRAINT PK_NHAN_VIEN PRIMARY KEY (MaNhanVien)
);
GO

-- =============================================
-- BANG HANG HOA
-- =============================================
CREATE TABLE HANG_HOA (
    MaHangHoa   NVARCHAR(10)  NOT NULL,
    TenHangHoa  NVARCHAR(100) NOT NULL,
    DonViTinh   NVARCHAR(20)  NULL,
    DonGiaNiemYet MONEY       NULL,
    CONSTRAINT PK_HANG_HOA PRIMARY KEY (MaHangHoa)
);
GO

-- =============================================
-- BANG DON HANG
-- =============================================
CREATE TABLE DON_HANG (
    MaDonHang    NVARCHAR(10)  NOT NULL,
    NgayMua      DATETIME      NOT NULL DEFAULT GETDATE(),
    TienVanChuyen MONEY        NULL DEFAULT 0,
    MaKhachHang  NVARCHAR(10)  NOT NULL,
    MaNhanVien   NVARCHAR(10)  NOT NULL,
    CONSTRAINT PK_DON_HANG PRIMARY KEY (MaDonHang),
    CONSTRAINT FK_DONHANG_KHACHHANG FOREIGN KEY (MaKhachHang)
        REFERENCES KHACH_HANG(MaKhachHang),
    CONSTRAINT FK_DONHANG_NHANVIEN FOREIGN KEY (MaNhanVien)
        REFERENCES NHAN_VIEN(MaNhanVien)
);
GO

-- =============================================
-- BANG CHI TIET DON HANG (quan he n-n giua DonHang va HangHoa)
-- =============================================
CREATE TABLE CHI_TIET_DON_HANG (
    MaDonHang  NVARCHAR(10)  NOT NULL,
    MaHangHoa  NVARCHAR(10)  NOT NULL,
    DonGiaBan  MONEY         NOT NULL,
    SoLuong    INT           NOT NULL DEFAULT 1,
    CONSTRAINT PK_CTDH PRIMARY KEY (MaDonHang, MaHangHoa),
    CONSTRAINT FK_CTDH_DONHANG FOREIGN KEY (MaDonHang)
        REFERENCES DON_HANG(MaDonHang)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_CTDH_HANGHOA FOREIGN KEY (MaHangHoa)
        REFERENCES HANG_HOA(MaHangHoa)
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO KHACH_HANG VALUES
    ('KH001', N'Nguyễn', N'Giang', '1990-03-15', N'Nam', N'10 Lê Văn Sỹ, Q3', '0901111222'),
    ('KH002', N'Phạm', N'Hương', '1995-07-22', N'Nữ', N'20 Cách Mạng Tháng 8, Q3', '0912222333'),
    ('KH003', N'Vũ', N'Khải', '1988-12-01', N'Nam', N'30 Nguyễn Thị Minh Khai, Q1', '0923333444');

INSERT INTO NHAN_VIEN VALUES
    ('NV001', N'Đỗ', N'Linh', '1992-05-10', N'Nữ', N'40 Đinh Tiên Hoàng, Q1', '0934444555'),
    ('NV002', N'Hoàng', N'Minh', '1990-09-25', N'Nam', N'50 Bà Huyện Thanh Quan, Q3', '0945555666'),
    ('NV003', N'Bùi', N'Ngọc', '1994-01-18', N'Nữ', N'60 Võ Thị Sáu, Q3', '0956666777');

INSERT INTO HANG_HOA VALUES
    ('HH001', N'Laptop Dell Inspiron 15', N'Cái', 18500000),
    ('HH002', N'Chuột không dây Logitech', N'Cái', 450000),
    ('HH003', N'Bàn phím cơ Keychron K2', N'Cái', 1800000),
    ('HH004', N'Màn hình LG 24 inch', N'Cái', 4200000);

INSERT INTO DON_HANG VALUES
    ('DH001', '2024-04-01 10:30:00', 50000, 'KH001', 'NV001'),
    ('DH002', '2024-04-05 14:00:00', 0, 'KH002', 'NV002'),
    ('DH003', '2024-04-10 09:15:00', 30000, 'KH003', 'NV001');

INSERT INTO CHI_TIET_DON_HANG VALUES
    ('DH001', 'HH001', 18000000, 1),
    ('DH001', 'HH002', 420000, 2),
    ('DH002', 'HH003', 1750000, 1),
    ('DH002', 'HH004', 4100000, 1),
    ('DH003', 'HH002', 420000, 3);
GO

PRINT N'Bai 7 - QLBanHang da tao thanh cong!';
GO
