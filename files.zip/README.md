# BTH02_SQL - Các bài thực hành thiết kế CSDL

## Danh sách file

| File | CSDL | Mô tả |
|------|------|-------|
| `Bai1_QLThueSach.sql` | QLThueSach | Quản lý cho thuê sách |
| `Bai2_QLThueDia.sql` | QLThueDia | Quản lý cho thuê đĩa nhạc/phim |
| `Bai3_QLThuePhong.sql` | QLThuePhong | Quản lý cho thuê phòng khách sạn |
| `Bai4_QLThueSan.sql` | QLThueSan | Quản lý cho thuê sân quần vợt |
| `Bai5_QLNhanSu.sql` | QLNhanSu | Quản lý nhân sự dự án |
| `Bai6_QLThuVien.sql` | QLThuVien | Quản lý thư viện |
| `Bai7_QLBanHang.sql` | QLBanHang | Quản lý bán hàng |
| `Bai8_QLChuyenBay.sql` | QLChuyenBay | Quản lý chuyến bay |

## Cách chạy trên SSMS

1. Mở **SQL Server Management Studio (SSMS)**
2. Connect vào SQL Server (localhost hoặc server của bạn)
3. Mở file `.sql` cần chạy: **File > Open > File...**
4. Nhấn **F5** hoặc click **Execute** để chạy

> **Lưu ý:** Mỗi file sẽ tự động **DROP** database cũ (nếu có) rồi tạo mới,
> nên có thể chạy lại nhiều lần mà không bị lỗi.

## Cấu trúc chung các bài

Mỗi bài gồm:
- Tạo database
- Tạo các bảng với khóa chính (PRIMARY KEY) và khóa ngoại (FOREIGN KEY)
- Dữ liệu mẫu tối thiểu 3 records mỗi bảng
