-- =============================================
-- BAI 3: QUAN LY CHO THUE PHONG KHACH SAN
-- File: Bai3_QLThuePhong.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLThuePhong')
    DROP DATABASE QLThuePhong;
GO

CREATE DATABASE QLThuePhong;
GO

USE QLThuePhong;
GO

-- =============================================
-- BANG PHONG
-- =============================================
CREATE TABLE PHONG (
    MaPhong        NVARCHAR(10)  NOT NULL,
    SoGiuong       INT           NULL,
    HoTenNVPhuTrach NVARCHAR(50) NULL,
    GiaTien        MONEY         NULL,
    GhiChu         NVARCHAR(MAX) NULL,
    CONSTRAINT PK_PHONG PRIMARY KEY (MaPhong)
);
GO

-- =============================================
-- BANG KHACH HANG
-- =============================================
CREATE TABLE KHACH_HANG (
    MaKhachHang  INT IDENTITY(1,1) NOT NULL,
    TenKhachHang NVARCHAR(50)  NOT NULL,
    DiaChi       NVARCHAR(100) NULL,
    SoDienThoai  NVARCHAR(12)  NULL,
    GhiChu       NVARCHAR(MAX) NULL,
    CONSTRAINT PK_KHACH_HANG PRIMARY KEY (MaKhachHang)
);
GO

-- =============================================
-- BANG THUE PHONG
-- =============================================
CREATE TABLE THUE_PHONG (
    MaKhachHang INT           NOT NULL,
    MaPhong     NVARCHAR(10)  NOT NULL,
    NgayLayPhong DATETIME     NOT NULL,
    NgayTraPhong DATETIME     NULL,
    SoTienDaTra  MONEY        NULL,
    GhiChu       NVARCHAR(MAX) NULL,
    CONSTRAINT PK_THUE_PHONG PRIMARY KEY (MaKhachHang, MaPhong, NgayLayPhong),
    CONSTRAINT FK_THUEPHONG_KHACHHANG FOREIGN KEY (MaKhachHang)
        REFERENCES KHACH_HANG(MaKhachHang)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_THUEPHONG_PHONG FOREIGN KEY (MaPhong)
        REFERENCES PHONG(MaPhong)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO PHONG VALUES
    ('P101', 1, N'Nguyễn Thị Hoa', 500000, N'Phòng đơn tầng 1'),
    ('P201', 2, N'Trần Văn Nam', 800000, N'Phòng đôi tầng 2'),
    ('P301', 3, N'Lê Thị Mai', 1200000, N'Phòng ba giường VIP');

INSERT INTO KHACH_HANG (TenKhachHang, DiaChi, SoDienThoai) VALUES
    (N'Hoàng Văn Phúc', N'78 Nguyễn Đình Chiểu, Q3, TP.HCM', '0967890123'),
    (N'Đinh Thị Quỳnh', N'90 Võ Thị Sáu, Q3, TP.HCM', '0978901234'),
    (N'Bùi Xuân Rồng', N'102 Hai Bà Trưng, Q1, TP.HCM', '0989012345');

INSERT INTO THUE_PHONG VALUES
    (1, 'P101', '2024-03-01 14:00:00', '2024-03-03 12:00:00', 1000000, NULL),
    (2, 'P201', '2024-03-05 14:00:00', NULL, 800000, N'Đang ở'),
    (3, 'P301', '2024-03-10 14:00:00', '2024-03-13 12:00:00', 3600000, NULL);
GO

PRINT N'Bai 3 - QLThuePhong da tao thanh cong!';
GO
