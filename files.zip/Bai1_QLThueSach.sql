-- =============================================
-- BAI 1: QUAN LY CHO THUE SACH
-- File: Bai1_QLThueSach.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLThueSach')
    DROP DATABASE QLThueSach;
GO

CREATE DATABASE QLThueSach;
GO

USE QLThueSach;
GO

-- =============================================
-- BANG LOAI SACH
-- =============================================
CREATE TABLE LOAI_SACH (
    MaLoaiSach  NVARCHAR(10)  NOT NULL,
    TenLoaiSach NVARCHAR(100) NOT NULL,
    MieuTa      NVARCHAR(255) NULL,
    CONSTRAINT PK_LOAI_SACH PRIMARY KEY (MaLoaiSach)
);
GO

-- =============================================
-- BANG SACH
-- =============================================
CREATE TABLE SACH (
    MaSach     NVARCHAR(10)  NOT NULL,
    TenSach    NVARCHAR(50)  NOT NULL,
    TacGia     NVARCHAR(50)  NULL,
    NhaXuatBan NVARCHAR(50)  NULL,
    GiaMuaVao  MONEY         NULL,
    MaLoaiSach NVARCHAR(10)  NULL,
    GhiChu     NVARCHAR(MAX) NULL,
    CONSTRAINT PK_SACH PRIMARY KEY (MaSach),
    CONSTRAINT FK_SACH_LOAISACH FOREIGN KEY (MaLoaiSach)
        REFERENCES LOAI_SACH(MaLoaiSach)
        ON UPDATE CASCADE ON DELETE SET NULL
);
GO

-- =============================================
-- BANG KHACH HANG
-- =============================================
CREATE TABLE KHACH_HANG (
    MaKhachHang  INT IDENTITY(1,1) NOT NULL,
    TenKhachHang NVARCHAR(50)  NOT NULL,
    DiaChi       NVARCHAR(100) NULL,
    SoDienThoai  NVARCHAR(12)  NULL,
    LoaiSachYeuThich NVARCHAR(100) NULL,
    GhiChu       NVARCHAR(MAX) NULL,
    CONSTRAINT PK_KHACH_HANG PRIMARY KEY (MaKhachHang)
);
GO

-- =============================================
-- BANG THUE SACH
-- =============================================
CREATE TABLE THUE_SACH (
    MaKhachHang    INT           NOT NULL,
    MaSach         NVARCHAR(10)  NOT NULL,
    NgayGioMuon    DATETIME      NOT NULL,
    NgayGioTra     DATETIME      NULL,
    SoTienThue     MONEY         NULL,
    GhiChu         NVARCHAR(MAX) NULL,
    CONSTRAINT PK_THUE_SACH PRIMARY KEY (MaKhachHang, MaSach, NgayGioMuon),
    CONSTRAINT FK_THUESACH_KHACHHANG FOREIGN KEY (MaKhachHang)
        REFERENCES KHACH_HANG(MaKhachHang)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_THUESACH_SACH FOREIGN KEY (MaSach)
        REFERENCES SACH(MaSach)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO LOAI_SACH VALUES
    ('LS001', N'Văn học', N'Sách văn học trong và ngoài nước'),
    ('LS002', N'Khoa học kỹ thuật', N'Sách kỹ thuật, công nghệ'),
    ('LS003', N'Kinh tế', N'Sách kinh doanh, tài chính');

INSERT INTO SACH VALUES
    ('S001', N'Dế Mèn Phiêu Lưu Ký', N'Tô Hoài', N'NXB Kim Đồng', 45000, 'LS001', NULL),
    ('S002', N'Lập trình C#', N'Nguyễn Văn A', N'NXB Thống Kê', 120000, 'LS002', NULL),
    ('S003', N'Khởi nghiệp tinh gọn', N'Eric Ries', N'NXB Trẻ', 95000, 'LS003', NULL);

INSERT INTO KHACH_HANG (TenKhachHang, DiaChi, SoDienThoai, LoaiSachYeuThich) VALUES
    (N'Nguyễn Văn Bình', N'123 Lê Lợi, Q1, TP.HCM', '0901234567', N'Văn học'),
    (N'Trần Thị Cẩm', N'456 Nguyễn Huệ, Q1, TP.HCM', '0912345678', N'Khoa học kỹ thuật'),
    (N'Lê Hoàng Dũng', N'789 Điện Biên Phủ, Q3, TP.HCM', '0923456789', N'Kinh tế');

INSERT INTO THUE_SACH VALUES
    (1, 'S001', '2024-01-10 09:00:00', '2024-01-17 10:00:00', 5000, NULL),
    (2, 'S002', '2024-01-12 14:00:00', NULL, 8000, N'Chưa trả'),
    (3, 'S003', '2024-01-15 08:30:00', '2024-01-22 09:00:00', 6000, NULL);
GO

PRINT N'Bai 1 - QLThueSach da tao thanh cong!';
GO
