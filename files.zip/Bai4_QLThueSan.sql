-- =============================================
-- BAI 4: QUAN LY CHO THUE SAN QUAN VOT
-- File: Bai4_QLThueSan.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLThueSan')
    DROP DATABASE QLThueSan;
GO

CREATE DATABASE QLThueSan;
GO

USE QLThueSan;
GO

-- =============================================
-- BANG SAN
-- =============================================
CREATE TABLE SAN (
    MaSan    NVARCHAR(10)  NOT NULL,
    TinhTrang NVARCHAR(50) NULL,
    GiaThue  MONEY         NULL,
    GhiChu   NVARCHAR(MAX) NULL,
    CONSTRAINT PK_SAN PRIMARY KEY (MaSan)
);
GO

-- =============================================
-- BANG KHACH HANG
-- =============================================
CREATE TABLE KHACH_HANG (
    MaKhachHang  INT IDENTITY(1,1) NOT NULL,
    TenKhachHang NVARCHAR(50)  NOT NULL,
    DiaChi       NVARCHAR(100) NULL,
    SoDienThoai  NVARCHAR(12)  NULL,
    GhiChu       NVARCHAR(MAX) NULL,
    CONSTRAINT PK_KHACH_HANG PRIMARY KEY (MaKhachHang)
);
GO

-- =============================================
-- BANG THUE SAN
-- =============================================
CREATE TABLE THUE_SAN (
    MaKhachHang INT           NOT NULL,
    MaSan       NVARCHAR(10)  NOT NULL,
    NgayGioThue DATETIME      NOT NULL,
    NgayGioTra  DATETIME      NULL,
    SoTienThu   MONEY         NULL,
    GhiChu      NVARCHAR(MAX) NULL,
    CONSTRAINT PK_THUE_SAN PRIMARY KEY (MaKhachHang, MaSan, NgayGioThue),
    CONSTRAINT FK_THUESAN_KHACHHANG FOREIGN KEY (MaKhachHang)
        REFERENCES KHACH_HANG(MaKhachHang)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_THUESAN_SAN FOREIGN KEY (MaSan)
        REFERENCES SAN(MaSan)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO SAN VALUES
    ('SAN01', N'Tốt', 100000, N'Sân trong nhà'),
    ('SAN02', N'Khá tốt', 80000, N'Sân ngoài trời có mái che'),
    ('SAN03', N'Đang sửa chữa', 0, N'Tạm ngưng cho thuê');

INSERT INTO KHACH_HANG (TenKhachHang, DiaChi, SoDienThoai) VALUES
    (N'Cao Văn Sơn', N'15 Cộng Hòa, Tân Bình, TP.HCM', '0990123456'),
    (N'Mai Thị Tuyết', N'27 Hoàng Văn Thụ, Phú Nhuận, TP.HCM', '0901234560'),
    (N'Đặng Hữu Uy', N'39 Phan Đình Phùng, Phú Nhuận, TP.HCM', '0912345601');

INSERT INTO THUE_SAN VALUES
    (1, 'SAN01', '2024-04-01 07:00:00', '2024-04-01 09:00:00', 200000, NULL),
    (2, 'SAN02', '2024-04-03 08:00:00', '2024-04-03 10:00:00', 160000, NULL),
    (3, 'SAN01', '2024-04-05 17:00:00', NULL, 100000, N'Đang thuê');
GO

PRINT N'Bai 4 - QLThueSan da tao thanh cong!';
GO
