-- =============================================
-- BAI 2: QUAN LY CHO THUE DIA NHAC, PHIM
-- File: Bai2_QLThueDia.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLThueDia')
    DROP DATABASE QLThueDia;
GO

CREATE DATABASE QLThueDia;
GO

USE QLThueDia;
GO

-- =============================================
-- BANG DIA
-- =============================================
CREATE TABLE DIA (
    MaDia        NVARCHAR(10)  NOT NULL,
    TenDia       NVARCHAR(50)  NOT NULL,
    TheLoai      NVARCHAR(20)  NULL,
    NuocSanXuat  NVARCHAR(20)  NULL,
    GiaMuaVao    MONEY         NULL,
    GhiChu       NVARCHAR(MAX) NULL,
    CONSTRAINT PK_DIA PRIMARY KEY (MaDia)
);
GO

-- =============================================
-- BANG KHACH HANG
-- =============================================
CREATE TABLE KHACH_HANG (
    MaKhachHang     INT IDENTITY(1,1) NOT NULL,
    TenKhachHang    NVARCHAR(50)  NOT NULL,
    DiaChi          NVARCHAR(100) NULL,
    SoDienThoai     NVARCHAR(12)  NULL,
    TheLoaiYeuThich NVARCHAR(20)  NULL,
    GhiChu          NVARCHAR(MAX) NULL,
    CONSTRAINT PK_KHACH_HANG PRIMARY KEY (MaKhachHang)
);
GO

-- =============================================
-- BANG THUE DIA
-- =============================================
CREATE TABLE THUE_DIA (
    MaKhachHang INT           NOT NULL,
    MaDia       NVARCHAR(10)  NOT NULL,
    NgayGioThue DATETIME      NOT NULL,
    NgayGioTra  DATETIME      NULL,
    SoTienThu   MONEY         NULL,
    GhiChu      NVARCHAR(MAX) NULL,
    CONSTRAINT PK_THUE_DIA PRIMARY KEY (MaKhachHang, MaDia, NgayGioThue),
    CONSTRAINT FK_THUEDIA_KHACHHANG FOREIGN KEY (MaKhachHang)
        REFERENCES KHACH_HANG(MaKhachHang)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_THUEDIA_DIA FOREIGN KEY (MaDia)
        REFERENCES DIA(MaDia)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO DIA VALUES
    ('D001', N'Avengers: Endgame', N'Phim', N'Mỹ', 150000, NULL),
    ('D002', N'Sơn Tùng MTP - Album Sky Tour', N'Nhạc', N'Việt Nam', 80000, NULL),
    ('D003', N'Your Name', N'Phim', N'Nhật Bản', 120000, NULL);

INSERT INTO KHACH_HANG (TenKhachHang, DiaChi, SoDienThoai, TheLoaiYeuThich) VALUES
    (N'Phạm Minh Tuấn', N'12 Trần Hưng Đạo, Q5, TP.HCM', '0934567890', N'Phim'),
    (N'Ngô Thị Lan', N'34 Cách Mạng Tháng 8, Q10, TP.HCM', '0945678901', N'Nhạc'),
    (N'Vũ Đức Mạnh', N'56 Lý Thường Kiệt, Q11, TP.HCM', '0956789012', N'Phim');

INSERT INTO THUE_DIA VALUES
    (1, 'D001', '2024-02-01 10:00:00', '2024-02-03 10:00:00', 15000, NULL),
    (2, 'D002', '2024-02-05 14:00:00', NULL, 10000, N'Chưa trả'),
    (3, 'D003', '2024-02-10 09:00:00', '2024-02-12 09:00:00', 12000, NULL);
GO

PRINT N'Bai 2 - QLThueDia da tao thanh cong!';
GO
