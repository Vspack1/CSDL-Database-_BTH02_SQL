-- =============================================
-- BAI 6: QUAN LY THU VIEN
-- File: Bai6_QLThuVien.sql
-- =============================================

USE master;
GO

IF EXISTS (SELECT name FROM sys.databases WHERE name = N'QLThuVien')
    DROP DATABASE QLThuVien;
GO

CREATE DATABASE QLThuVien;
GO

USE QLThuVien;
GO

-- =============================================
-- BANG NHA XUAT BAN
-- =============================================
CREATE TABLE NHA_XUAT_BAN (
    MaNXB   NVARCHAR(10)  NOT NULL,
    TenNXB  NVARCHAR(100) NOT NULL,
    DiaChi  NVARCHAR(100) NULL,
    Website NVARCHAR(100) NULL,
    CONSTRAINT PK_NHA_XUAT_BAN PRIMARY KEY (MaNXB)
);
GO

-- =============================================
-- BANG TAC GIA
-- =============================================
CREATE TABLE TAC_GIA (
    MaTacGia   NVARCHAR(10)  NOT NULL,
    TenTacGia  NVARCHAR(50)  NOT NULL,
    QuocTich   NVARCHAR(30)  NULL,
    GhiChu     NVARCHAR(MAX) NULL,
    CONSTRAINT PK_TAC_GIA PRIMARY KEY (MaTacGia)
);
GO

-- =============================================
-- BANG SACH
-- =============================================
CREATE TABLE SACH (
    MaSach     NVARCHAR(10)  NOT NULL,
    TenSach    NVARCHAR(100) NOT NULL,
    MaNXB      NVARCHAR(10)  NULL,
    NamXuatBan INT           NULL,
    CONSTRAINT PK_SACH PRIMARY KEY (MaSach),
    CONSTRAINT FK_SACH_NXB FOREIGN KEY (MaNXB)
        REFERENCES NHA_XUAT_BAN(MaNXB)
        ON UPDATE CASCADE ON DELETE SET NULL
);
GO

-- =============================================
-- BANG SACH_TACGIA (quan he n-n giua Sach va Tac Gia)
-- =============================================
CREATE TABLE SACH_TACGIA (
    MaSach   NVARCHAR(10) NOT NULL,
    MaTacGia NVARCHAR(10) NOT NULL,
    CONSTRAINT PK_SACH_TACGIA PRIMARY KEY (MaSach, MaTacGia),
    CONSTRAINT FK_SACHTACGIA_SACH FOREIGN KEY (MaSach)
        REFERENCES SACH(MaSach)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_SACHTACGIA_TACGIA FOREIGN KEY (MaTacGia)
        REFERENCES TAC_GIA(MaTacGia)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- BANG DOC GIA
-- =============================================
CREATE TABLE DOC_GIA (
    MaDocGia  NVARCHAR(10)  NOT NULL,
    TenDocGia NVARCHAR(50)  NOT NULL,
    NgaySinh  DATE          NULL,
    DiaChi    NVARCHAR(100) NULL,
    Email     NVARCHAR(50)  NULL,
    CONSTRAINT PK_DOC_GIA PRIMARY KEY (MaDocGia)
);
GO

-- =============================================
-- BANG MUON_TRA (moi lan muon sach)
-- Mot doc gia co the muon mot cuon nhieu lan
-- => khoa chinh: MaDocGia + MaSach + NgayGioMuon
-- =============================================
CREATE TABLE MUON_TRA (
    MaDocGia      NVARCHAR(10)  NOT NULL,
    MaSach        NVARCHAR(10)  NOT NULL,
    NgayGioMuon   DATETIME      NOT NULL,
    NgayGioTra    DATETIME      NULL,
    TinhTrangMuon NVARCHAR(50)  NULL,
    TinhTrangTra  NVARCHAR(50)  NULL,
    CONSTRAINT PK_MUON_TRA PRIMARY KEY (MaDocGia, MaSach, NgayGioMuon),
    CONSTRAINT FK_MUONTRA_DOCGIA FOREIGN KEY (MaDocGia)
        REFERENCES DOC_GIA(MaDocGia)
        ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT FK_MUONTRA_SACH FOREIGN KEY (MaSach)
        REFERENCES SACH(MaSach)
        ON UPDATE CASCADE ON DELETE CASCADE
);
GO

-- =============================================
-- DU LIEU MAU
-- =============================================
INSERT INTO NHA_XUAT_BAN VALUES
    ('NXB001', N'NXB Kim Đồng', N'55 Quang Trung, Hà Nội', 'kimdong.com.vn'),
    ('NXB002', N'NXB Trẻ', N'161B Lý Chính Thắng, Q3, TP.HCM', 'nxbtre.com.vn'),
    ('NXB003', N'NXB Giáo Dục', N'81 Trần Hưng Đạo, Hà Nội', 'nxbgd.vn');

INSERT INTO TAC_GIA VALUES
    ('TG001', N'Tô Hoài', N'Việt Nam', N'Tác giả Dế Mèn Phiêu Lưu Ký'),
    ('TG002', N'Nam Cao', N'Việt Nam', NULL),
    ('TG003', N'Paulo Coelho', N'Brazil', N'Tác giả The Alchemist');

INSERT INTO SACH VALUES
    ('SC001', N'Dế Mèn Phiêu Lưu Ký', 'NXB001', 2020),
    ('SC002', N'Chí Phèo', 'NXB002', 2019),
    ('SC003', N'Nhà Giả Kim', 'NXB002', 2022);

INSERT INTO SACH_TACGIA VALUES
    ('SC001', 'TG001'),
    ('SC002', 'TG002'),
    ('SC003', 'TG003');

INSERT INTO DOC_GIA VALUES
    ('DG001', N'Trần Văn Đức', '2000-05-15', N'12 Đinh Tiên Hoàng, Q1', 'duc@email.com'),
    ('DG002', N'Nguyễn Thị Em', '1998-08-20', N'34 Nguyễn Bỉnh Khiêm, Q1', 'em@email.com'),
    ('DG003', N'Lê Hoàng Phúc', '2001-11-30', N'56 Đinh Bộ Lĩnh, BT', 'phuc@email.com');

INSERT INTO MUON_TRA VALUES
    ('DG001', 'SC001', '2024-01-05 09:00:00', '2024-01-12 10:00:00', N'Tốt', N'Tốt'),
    ('DG001', 'SC002', '2024-02-10 14:00:00', NULL, N'Bình thường', NULL),
    ('DG002', 'SC003', '2024-01-20 08:00:00', '2024-01-30 09:00:00', N'Tốt', N'Có vết bẩn nhỏ'),
    ('DG003', 'SC001', '2024-02-15 10:00:00', NULL, N'Tốt', NULL);
GO

PRINT N'Bai 6 - QLThuVien da tao thanh cong!';
GO
